import React, { useEffect, useState } from 'react';
import { plateService, busService, stationService } from '../../services/apiServices';
import { toast } from 'react-toastify';
import { Plus, Trash2, Edit, CheckCircle, AlertCircle } from 'lucide-react';

export default function PlateVerification() {
  const [plates, setPlates] = useState([]);
  const [buses, setBuses] = useState([]);
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    numberPlate: '',
    stationId: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [platesRes, busesRes, stationsRes] = await Promise.all([
        plateService.getAllPlateEntries(filter !== 'all' ? filter : null),
        busService.getAllBuses(),
        stationService.getAllStations()
      ]);

      setPlates(platesRes.data || []);
      setBuses(busesRes.data || []);
      setStations(stationsRes.data || []);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.numberPlate || !formData.stationId) {
      toast.error('Please fill all fields');
      return;
    }

    try {
      if (editingId) {
        await plateService.updatePlateEntry(editingId, {
          numberPlate: formData.numberPlate,
          stationId: formData.stationId
        });
        toast.success('Plate entry updated');
        setEditingId(null);
      } else {
        await plateService.createPlateEntry({
          numberPlate: formData.numberPlate,
          stationId: formData.stationId
        });
        toast.success('Plate entry created');
      }

      setFormData({ numberPlate: '', stationId: '' });
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Operation failed');
    }
  };

  const handleEdit = (plate) => {
    setEditingId(plate._id);
    setFormData({
      numberPlate: plate.capturedNumberPlate,
      stationId: plate.stationId._id
    });
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this entry?')) {
      try {
        await plateService.deletePlateEntry(id);
        toast.success('Plate entry deleted');
        fetchData();
      } catch (error) {
        toast.error('Failed to delete');
      }
    }
  };

  const handleVerify = async (id, verified) => {
    try {
      await plateService.verifyPlateEntry(id, verified);
      toast.success(`Plate entry ${verified ? 'verified' : 'rejected'}`);
      fetchData();
    } catch (error) {
      toast.error('Failed to verify');
    }
  };

  return (
    <div className="space-y-6">
      {/* Entry Form */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">
          {editingId ? 'Update Plate Entry' : 'Create Plate Entry'}
        </h2>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Number Plate
            </label>
            <input
              type="text"
              value={formData.numberPlate}
              onChange={(e) => setFormData({ ...formData, numberPlate: e.target.value.toUpperCase() })}
              placeholder="MH-01-AB-1234"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Station
            </label>
            <select
              value={formData.stationId}
              onChange={(e) => setFormData({ ...formData, stationId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Station</option>
              {stations.map((s) => (
                <option key={s._id} value={s._id}>
                  {s.stationName}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end gap-2">
            <button
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {editingId ? 'Update' : 'Create'}
            </button>
          </div>

          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setFormData({ numberPlate: '', stationId: '' });
              }}
              className="bg-gray-400 hover:bg-gray-500 text-white font-medium py-2 px-4 rounded-lg"
            >
              Cancel
            </button>
          )}
        </form>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex gap-2 flex-wrap">
          {['all', 'pending', 'verified', 'rejected'].map((status) => (
            <button
              key={status}
              onClick={() => {
                setFilter(status);
                setPlates([]);
              }}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                filter === status
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Plates List */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Plate Number</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Station</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Matched Bus</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="5" className="px-6 py-4 text-center text-gray-500">
                  Loading...
                </td>
              </tr>
            ) : plates.length === 0 ? (
              <tr>
                <td colSpan="5" className="px-6 py-4 text-center text-gray-500">
                  No plate entries found
                </td>
              </tr>
            ) : (
              plates.map((plate) => (
                <tr key={plate._id} className="border-b hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-800">
                    {plate.capturedNumberPlate}
                  </td>
                  <td className="px-6 py-4 text-gray-700">
                    {plate.stationId?.stationName}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      plate.status === 'verified' ? 'bg-green-100 text-green-800' :
                      plate.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {plate.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-700">
                    {plate.matchedBusId?.busId || '-'}
                  </td>
                  <td className="px-6 py-4 flex gap-2">
                    {plate.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleVerify(plate._id, true)}
                          className="text-green-600 hover:text-green-800 p-1"
                          title="Verify"
                        >
                          <CheckCircle className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleVerify(plate._id, false)}
                          className="text-red-600 hover:text-red-800 p-1"
                          title="Reject"
                        >
                          <AlertCircle className="w-5 h-5" />
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => handleEdit(plate)}
                      className="text-blue-600 hover:text-blue-800 p-1"
                      title="Edit"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(plate._id)}
                      className="text-red-600 hover:text-red-800 p-1"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
