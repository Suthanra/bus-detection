const express = require('express');
const router = express.Router();
const gpsController = require('../controllers/gpsController');
const authMiddleware = require('../middlewares/authMiddleware');

// All routes require authentication
router.use(authMiddleware);

// Submit GPS location (can be called frequently)
router.post('/update', gpsController.submitGPSLocation);

// Get latest location for a bus
router.get('/bus/:busId/latest', gpsController.getLatestLocation);

// Get location history
router.get('/bus/:busId/history', gpsController.getLocationHistory);

// Get all buses current locations
router.get('/all/current', gpsController.getAllCurrentLocations);

// Cleanup old GPS data (admin only)
router.delete('/cleanup', gpsController.cleanupOldGPSData);

module.exports = router;
