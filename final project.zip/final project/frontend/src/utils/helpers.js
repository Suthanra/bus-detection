// Distance calculation using Haversine formula
export const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  return distance; // in kilometers
};

// Format time
export const formatTime = (date) => {
  return new Date(date).toLocaleTimeString();
};

// Format date
export const formatDate = (date) => {
  return new Date(date).toLocaleDateString();
};

// Format distance
export const formatDistance = (km) => {
  if (km < 1) {
    return `${(km * 1000).toFixed(0)}m`;
  }
  return `${km.toFixed(2)}km`;
};

// Validate registration number
export const validateRegistration = (registration) => {
  const pattern = /^[A-Z]{2}-\d{2}-[A-Z]{2}-\d{4}$/;
  return pattern.test(registration);
};

// Validate phone number
export const validatePhone = (phone) => {
  const pattern = /^[0-9]{10}$/;
  return pattern.test(phone.replace(/\D/g, ''));
};
