const mongoose = require('mongoose');

const gpsLocationSchema = new mongoose.Schema(
  {
    busId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bus',
      required: true
    },
    latitude: {
      type: Number,
      required: true
    },
    longitude: {
      type: Number,
      required: true
    },
    accuracy: {
      type: Number,
      default: null // in meters
    },
    speed: {
      type: Number,
      default: null // in km/h
    },
    direction: {
      type: Number,
      default: null // in degrees (0-360)
    },
    altitude: {
      type: Number,
      default: null // in meters
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true
    }
  },
  {
    timestamps: false
  }
);

// Compound index for efficient location history queries
gpsLocationSchema.index({ busId: 1, timestamp: -1 });
// TTL index to auto-delete old locations (not created here, set via job)
gpsLocationSchema.index({ timestamp: 1 }, { expireAfterSeconds: 2592000 }); // 30 days

module.exports = mongoose.model('GPSLocation', gpsLocationSchema);
