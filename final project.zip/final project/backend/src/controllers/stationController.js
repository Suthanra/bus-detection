const BusStation = require('../models/BusStation');

// @desc Get all stations
// @route GET /api/stations
// @access Private
exports.getAllStations = async (req, res, next) => {
  try {
    const stations = await BusStation.find().sort({ stationName: 1 });

    res.status(200).json({
      success: true,
      count: stations.length,
      data: stations
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get single station
// @route GET /api/stations/:id
// @access Private
exports.getStationById = async (req, res, next) => {
  try {
    const station = await BusStation.findById(req.params.id);

    if (!station) {
      return res.status(404).json({
        success: false,
        message: 'Station not found'
      });
    }

    res.status(200).json({
      success: true,
      data: station
    });
  } catch (error) {
    next(error);
  }
};

// @desc Create new station
// @route POST /api/stations
// @access Private (Admin)
exports.createStation = async (req, res, next) => {
  try {
    const station = await BusStation.create(req.body);

    res.status(201).json({
      success: true,
      message: 'Station created successfully',
      data: station
    });
  } catch (error) {
    next(error);
  }
};

// @desc Update station
// @route PUT /api/stations/:id
// @access Private (Admin)
exports.updateStation = async (req, res, next) => {
  try {
    let station = await BusStation.findById(req.params.id);

    if (!station) {
      return res.status(404).json({
        success: false,
        message: 'Station not found'
      });
    }

    station = await BusStation.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      message: 'Station updated successfully',
      data: station
    });
  } catch (error) {
    next(error);
  }
};

// @desc Delete station
// @route DELETE /api/stations/:id
// @access Private (Admin)
exports.deleteStation = async (req, res, next) => {
  try {
    const station = await BusStation.findByIdAndDelete(req.params.id);

    if (!station) {
      return res.status(404).json({
        success: false,
        message: 'Station not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Station deleted successfully',
      data: station
    });
  } catch (error) {
    next(error);
  }
};
