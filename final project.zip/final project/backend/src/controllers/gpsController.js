const GPSLocation = require('../models/GPSLocation');
const Bus = require('../models/Bus');
const geoFenceService = require('../services/geoFenceService');
const tripService = require('../services/tripService');

// @desc Submit GPS location
// @route POST /api/gps/update
// @access Private
exports.submitGPSLocation = async (req, res, next) => {
  try {
    const { busId, latitude, longitude, accuracy, speed, direction } = req.body;

    // Validate bus exists
    const bus = await Bus.findById(busId);
    if (!bus) {
      return res.status(404).json({
        success: false,
        message: 'Bus not found'
      });
    }

    // Create GPS location record
    const gpsLocation = await GPSLocation.create({
      busId,
      latitude,
      longitude,
      accuracy: accuracy || null,
      speed: speed || null,
      direction: direction || null
    });

    // Update bus last location
    bus.lastLocationUpdate = new Date();
    bus.currentLocation = {
      latitude,
      longitude
    };
    await bus.save();

    // Check geofence
    const geofenceResult = await geoFenceService.checkBusInGeofence(
      busId,
      latitude,
      longitude
    );

    if (geofenceResult.inGeofence) {
      // Update trip status
      await tripService.updateTripStatusByGeofence(busId, geofenceResult.stationId);
    }

    // Emit socket event for real-time update
    if (req.app.get('io')) {
      req.app.get('io').emit('bus-location-update', {
        busId,
        latitude,
        longitude,
        timestamp: gpsLocation.timestamp,
        geofence: geofenceResult
      });
    }

    res.status(201).json({
      success: true,
      message: 'GPS location recorded',
      data: {
        gpsLocation,
        geofence: geofenceResult
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get latest location for a bus
// @route GET /api/gps/bus/:busId/latest
// @access Private
exports.getLatestLocation = async (req, res, next) => {
  try {
    const location = await GPSLocation.findOne({ busId: req.params.busId })
      .sort({ timestamp: -1 });

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'No location found'
      });
    }

    res.status(200).json({
      success: true,
      data: location
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get location history for a bus
// @route GET /api/gps/bus/:busId/history
// @access Private
exports.getLocationHistory = async (req, res, next) => {
  try {
    const { days = 1, limit = 100 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));

    const locations = await GPSLocation.find({
      busId: req.params.busId,
      timestamp: { $gte: startDate }
    })
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: locations.length,
      data: locations
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get all buses current locations
// @route GET /api/gps/all/current
// @access Private
exports.getAllCurrentLocations = async (req, res, next) => {
  try {
    const buses = await Bus.find({ status: 'active' });
    const locations = [];

    for (const bus of buses) {
      const latestLocation = await GPSLocation.findOne({ busId: bus._id })
        .sort({ timestamp: -1 });

      if (latestLocation) {
        locations.push({
          bus,
          location: latestLocation
        });
      }
    }

    res.status(200).json({
      success: true,
      count: locations.length,
      data: locations
    });
  } catch (error) {
    next(error);
  }
};

// @desc Delete old GPS data (cleanup)
// @route DELETE /api/gps/cleanup
// @access Private (Admin)
exports.cleanupOldGPSData = async (req, res, next) => {
  try {
    const { days = 30 } = req.body;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const result = await GPSLocation.deleteMany({
      timestamp: { $lt: cutoffDate }
    });

    res.status(200).json({
      success: true,
      message: `Deleted ${result.deletedCount} old GPS records`,
      data: result
    });
  } catch (error) {
    next(error);
  }
};
