import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './index.css';

import { useAuthStore } from './utils/store';
import { connectSocket, disconnectSocket } from './services/socketService';

// Pages
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import PublicTracker from './pages/PublicTracker';

// Layout
import Sidebar from './components/Common/Sidebar';

// Components
import AdminDashboard from './components/Dashboard/AdminDashboard';
import BusList from './components/BusManagement/BusList';
import PlateVerification from './components/NumberPlate/PlateVerification';
import StationList from './components/StationManagement/StationList';
import TripList from './components/TripTracking/TripList';

function ProtectedRoute({ element }) {
  const { isLoggedIn } = useAuthStore();
  return isLoggedIn ? element : <Navigate to="/login" replace />;
}

export default function App() {
  const { isLoggedIn } = useAuthStore();

  useEffect(() => {
    if (isLoggedIn) {
      connectSocket();
    } else {
      disconnectSocket();
    }

    return () => {
      disconnectSocket();
    };
  }, [isLoggedIn]);

  return (
    <Router>
      <ToastContainer position="top-right" autoClose={3000} />

      {isLoggedIn ? (
        <div className="flex h-screen bg-gray-100">
          <Sidebar />
          <main className="flex-1 overflow-auto p-6">
            <Routes>
              <Route path="/dashboard" element={<ProtectedRoute element={<AdminDashboard />} />} />
              <Route path="/buses" element={<ProtectedRoute element={<BusList />} />} />
              <Route path="/stations" element={<ProtectedRoute element={<StationList />} />} />
              <Route path="/trips" element={<ProtectedRoute element={<TripList />} />} />
              <Route path="/plates" element={<ProtectedRoute element={<PlateVerification />} />} />
              <Route path="/tracker" element={<ProtectedRoute element={<PublicTracker />} />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </main>
        </div>
      ) : (
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      )}
    </Router>
  );
}
