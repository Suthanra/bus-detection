# Troubleshooting Guide - Bus Tracking System

Common issues and their solutions.

## 🔴 Backend Issues

### 1. MongoDB Connection Error
**Error:** `MongooseError: connect ECONNREFUSED 127.0.0.1:27017`

**Solution:**
```bash
# Start MongoDB
mongod

# Windows (if installed as service):
net start MongoDB
# or
sc start MongoDB

# macOS:
brew services start mongodb-community

# Linux:
sudo systemctl start mongod
```

### 2. Port 5000 Already in Use
**Error:** `EADDRINUSE: address already in use :::5000`

**Solution:**
```bash
# Option 1: Kill process using port 5000
# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/macOS:
lsof -i :5000
kill -9 <PID>

# Option 2: Change port in .env
PORT=5001
```

### 3. Missing Environment Variables
**Error:** `JWT_SECRET is not defined`

**Solution:**
- Create `backend/.env` file with all required variables
- Copy from `.env.example` or SETUP_GUIDE.md
- Check all variables are set: `MONGODB_URI`, `JWT_SECRET`, `PORT`, etc.

### 4. npm Dependencies Issues
**Error:** `Cannot find module 'express'`

**Solution:**
```bash
cd backend
rm -rf node_modules package-lock.json
npm install

# Force clear npm cache:
npm cache clean --force
npm install
```

### 5. Google Maps API Not Working
**Error:** `Google Maps API key error or blank map`

**Solution:**
- Get API key from [Google Cloud Console](https://console.cloud.google.com)
- Enable Maps JavaScript API
- Add key to `backend/.env`: `GOOGLE_MAPS_API_KEY=your_key_here`
- Restart backend server

### 6. JWT Token Issues
**Error:** `JsonWebTokenError: invalid token` or `TokenExpiredError`

**Solution:**
- Check `JWT_SECRET` is set correctly in `.env`
- Verify token is sent correctly: `Authorization: Bearer <token>`
- Check token expiration in `.env`: `JWT_EXPIRE=7d`
- Clear browser localStorage if stuck with old token

### 7. Database Connection Timeout
**Error:** `Timeout connecting to MongoDB`

**Solution:**
```bash
# Increase connection timeout in .env:
MONGODB_TIMEOUT=10000

# or check MongoDB service
mongod --version
```

---

## 🟡 Frontend Issues

### 1. Page Not Loading
**Error:** Blank page or white screen

**Solution:**
```bash
cd frontend
npm install
npm run dev

# If still blank:
rm -rf node_modules
npm install
npm run dev
```

### 2. Environment Variables Not Loading
**Error:** API calls return 404 or `localhost:5000` undefined

**Solution:**
- Create `frontend/.env` file:
  ```env
  VITE_API_URL=http://localhost:5000/api
  VITE_SOCKET_URL=http://localhost:5000
  ```
- Restart dev server after creating/changing `.env`
- Check variables with: `console.log(import.meta.env.VITE_API_URL)`

### 3. CORS Errors
**Error:** `Access to XMLHttpRequest blocked by CORS`

**Solution:**
- Check backend `CORS_ORIGIN` in `.env`:
  ```env
  CORS_ORIGIN=http://localhost:3000,http://localhost:5173
  ```
- Ensure frontend URL matches backend CORS settings
- Restart backend server
- Clear browser cache

### 4. Socket.io Connection Failed
**Error:** `WebSocket connection failed` or disconnect errors

**Solution:**
- Verify backend is running on correct port
- Check `VITE_SOCKET_URL` in frontend `.env`
- Ensure port matches between frontend and backend config
- Try: `http://localhost:5000` instead of domain name
- Check firewall/antivirus not blocking ports

### 5. Map Not Displaying
**Error:** `Google Maps not loading` or gray map area

**Solution:**
- Add Google Maps API key to backend `.env`
- Check API key has Maps JavaScript API enabled
- Verify key restrictions (if any) allow localhost
- Check browser console for errors (F12)
- Try zooming in/out on map

### 6. Real-time Updates Not Working
**Error:** Bus locations not updating in real-time

**Solution:**
- Check Socket.io connection in browser DevTools (Network tab)
- Verify backend socket handler is running
- Check for error messages in browser console
- Restart both frontend and backend servers
- Check firewall isn't blocking websocket connections

### 7. Login Not Working
**Error:** `Invalid username or password` (but credentials are correct)

**Solution:**
```bash
# Check user exists in database
# Run sample data script:
bash scripts/create-sample-data.sh

# Or manually create admin user via MongoDB:
db.users.findOne({ username: "admin" })

# If not exists, register new user through UI
```

---

## 🟠 General Issues

### 1. Port 3000/5173 Already in Use
**Error:** Frontend can't start on default port

**Solution:**
```bash
# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Linux/macOS:
kill -9 $(lsof -t -i :3000)

# Or use different port:
npm run dev -- --port 3001
```

### 2. Node Modules Cache Issues
**Error:** Old code being executed

**Solution:**
```bash
# Clear everything and reinstall
npm cache clean --force
rm -rf node_modules
rm package-lock.json
npm install

# Also clear .next, .vite if exists
rm -rf .next .vite
```

### 3. Process Won't Stop
**Error:** Can't stop npm dev server (nodemon, vite)

**Solution:**
```bash
# Press Ctrl+C multiple times

# If stuck, kill process:
# Windows:
taskkill /IM node.exe /F

# Linux/macOS:
killall node
```

### 4. Git/File Permission Issues
**Error:** `Permission denied` when running scripts

**Solution:**
```bash
# Make script executable:
chmod +x scripts/create-sample-data.sh

# Or run with bash explicitly:
bash scripts/create-sample-data.sh
```

---

## 📋 Diagnostic Commands

Run these to debug issues:

```bash
# Check Node.js
node --version
npm --version

# Check MongoDB
mongod --version
mongo --version

# Check ports in use
# Windows:
netstat -ano | findstr :5000
netstat -ano | findstr :3000

# Linux/macOS:
lsof -i :5000
lsof -i :3000

# Check environment variables
cat .env

# Check logs:
# Keep terminal open to see server logs

# Test API
curl http://localhost:5000/api/health

# Check if MongoDB is accessible
mongo mongodb://localhost:27017
```

---

## 🆘 Still Having Issues?

1. **Check logs** - Look at terminal output for error messages
2. **Clear cache** - Delete node_modules and reinstall
3. **Restart everything** - Stop and restart both servers
4. **Check .env files** - Ensure all variables are set
5. **Verify ports** - Make sure MongoDB, backend, frontend have unique ports
6. **Check documentation** - Review [SETUP_GUIDE.md](docs/SETUP_GUIDE.md)
7. **Contact support** - See [GETTING_HELP.md](GETTING_HELP.md)

---

## 💾 Database Issues

### Empty Database
```bash
# Check MongoDB running
mongod

# View databases
mongo
> show dbs

# Access bus-tracking database
> use bus-tracking-system

# View collections
> show collections

# Count users
> db.users.countDocuments()
```

### Reset Database
```bash
# Run sample data script
bash scripts/create-sample-data.sh

# Or manually drop and recreate
# WARNING: This deletes all data!
```

---

**Still stuck?** Check the error message carefully and search the documentation or create an issue!
