const { validationResult } = require('express-validator');

const validationMiddleware = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const extractedErrors = [];
    errors.array().forEach(err => {
      extractedErrors.push({
        field: err.param,
        message: err.msg
      });
    });

    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: extractedErrors
    });
  }

  next();
};

module.exports = validationMiddleware;
