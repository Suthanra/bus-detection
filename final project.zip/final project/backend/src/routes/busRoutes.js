const express = require('express');
const router = express.Router();
const busController = require('../controllers/busController');
const authMiddleware = require('../middlewares/authMiddleware');

// All routes require authentication
router.use(authMiddleware);

// Get all buses
router.get('/', busController.getAllBuses);

// Get single bus
router.get('/:id', busController.getBusById);

// Get bus by registration number
router.get('/search/:registrationNumber', busController.getBusByRegistration);

// Create bus
router.post('/', busController.createBus);

// Update bus
router.put('/:id', busController.updateBus);

// Delete bus
router.delete('/:id', busController.deleteBus);

module.exports = router;
