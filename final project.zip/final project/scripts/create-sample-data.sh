#!/bin/bash

# Bus Tracking System - Sample Data Creation Script
# This script creates sample buses, stations, and trips for testing

BASE_URL="http://localhost:5000/api"
TOKEN="" # Will be set after login

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}Bus Tracking System - Sample Data Creation${NC}"
echo "=========================================="

# Step 1: Register Admin
echo -e "\n${BLUE}Step 1: Creating Admin Account...${NC}"
ADMIN_RESPONSE=$(curl -s -X POST $BASE_URL/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "ADMIN001",
    "username": "admin",
    "email": "admin@example.com",
    "password": "admin@123",
    "firstName": "System",
    "lastName": "Admin",
    "role": "admin"
  }')

TOKEN=$(echo $ADMIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
  echo "Admin might already exist. Logging in..."
  LOGIN_RESPONSE=$(curl -s -X POST $BASE_URL/auth/login \
    -H "Content-Type: application/json" \
    -d '{
      "username": "admin",
      "password": "admin@123"
    }')
  TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

echo -e "${GREEN}✓ Admin Account Ready${NC}"
echo "Token: $TOKEN"

# Step 2: Create Sample Stations
echo -e "\n${BLUE}Step 2: Creating Sample Stations...${NC}"

STATIONS=(
  '{"stationId": "STN001", "stationName": "Central Bus Stand", "city": "Mumbai", "latitude": 19.0760, "longitude": 72.8777, "geofenceRadiusMeters": 200}'
  '{"stationId": "STN002", "stationName": "Airport Station", "city": "Mumbai", "latitude": 19.0895, "longitude": 72.8656, "geofenceRadiusMeters": 250}'
  '{"stationId": "STN003", "stationName": "Railway Station", "city": "Mumbai", "latitude": 18.9676, "longitude": 72.8194, "geofenceRadiusMeters": 200}'
)

for STATION in "${STATIONS[@]}"; do
  curl -s -X POST $BASE_URL/stations \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d "$STATION" > /dev/null
  echo -e "${GREEN}✓ Station Created${NC}"
done

# Step 3: Create Sample Buses
echo -e "\n${BLUE}Step 3: Creating Sample Buses...${NC}"

for i in {1..10}; do
  BUS_ID=$(printf "%03d" $i)
  REG_NUM="MH-01-AB-$(printf "%04d" $i)"
  
  curl -s -X POST $BASE_URL/buses \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d "{
      \"busId\": \"BUS$BUS_ID\",
      \"registrationNumber\": \"$REG_NUM\",
      \"driverName\": \"Driver $BUS_ID\",
      \"conductorName\": \"Conductor $BUS_ID\",
      \"conductorPhone\": \"98765432$(printf "%02d" $i)\",
      \"busType\": \"AC\",
      \"capacity\": 50,
      \"status\": \"active\"
    }" > /dev/null
  
  echo -e "${GREEN}✓ Bus BUS$BUS_ID Created${NC}"
done

echo -e "\n${GREEN}=========================================="
echo "Sample Data Creation Complete!"
echo "=========================================="
echo ""
echo "Created:"
echo "  - 1 Admin Account (admin / admin@123)"
echo "  - 3 Bus Stations"
echo "  - 10 Sample Buses"
echo ""
echo "Next Steps:"
echo "  1. Login to http://localhost:3000/login"
echo "  2. Navigate to Buses to see all 10 buses"
echo "  3. Navigate to Stations to see all 3 stations"
echo "  4. Create trips and submit GPS data"
echo ""
echo -e "${GREEN}Ready to test the system!${NC}"
