import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../utils/store';
import { LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const menuItems = [
    { label: 'Dashboard', path: '/dashboard', role: ['admin', 'operator'] },
    { label: 'Buses', path: '/buses', role: ['admin', 'operator'] },
    { label: 'Stations', path: '/stations', role: ['admin', 'operator'] },
    { label: 'Trips', path: '/trips', role: ['admin', 'operator', 'viewer'] },
    { label: 'Number Plates', path: '/plates', role: ['admin', 'operator'] },
    { label: 'Tracker', path: '/tracker', role: ['admin', 'operator', 'viewer'] }
  ];

  const filteredMenu = menuItems.filter(item => item.role.includes(user?.role));

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 bg-blue-600 text-white p-2 rounded-lg"
      >
        {isOpen ? <X /> : <Menu />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed md:static left-0 top-0 h-screen w-64 bg-gray-800 text-white transition-transform duration-300 z-40 ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="p-4 border-b border-gray-700">
          <h1 className="text-xl font-bold">Bus Tracker</h1>
          <p className="text-gray-400 text-sm">{user?.role.toUpperCase()}</p>
        </div>

        <nav className="flex-1 p-4">
          {filteredMenu.map((item) => (
            <button
              key={item.path}
              onClick={() => {
                navigate(item.path);
                setIsOpen(false);
              }}
              className="w-full text-left px-4 py-2 rounded-lg hover:bg-gray-700 transition mb-2"
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-700">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg transition"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 md:hidden z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
