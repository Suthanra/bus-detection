const TripTracking = require('../models/TripTracking');
const tripService = require('../services/tripService');
const constants = require('../config/constants');

// @desc Create new trip
// @route POST /api/trips
// @access Private
exports.createTrip = async (req, res, next) => {
  try {
    const trip = await tripService.createTrip(req.body);

    res.status(201).json({
      success: true,
      message: 'Trip created successfully',
      data: trip
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get all trips
// @route GET /api/trips
// @access Private
exports.getAllTrips = async (req, res, next) => {
  try {
    const { status, limit = 50 } = req.query;
    
    let query = {};
    if (status) query.status = status;

    const trips = await TripTracking.find(query)
      .populate('busId sourceStation destinationStation')
      .sort({ departureTime: -1 })
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: trips.length,
      data: trips
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get single trip
// @route GET /api/trips/:id
// @access Private
exports.getTripById = async (req, res, next) => {
  try {
    const trip = await TripTracking.findById(req.params.id)
      .populate('busId sourceStation destinationStation');

    if (!trip) {
      return res.status(404).json({
        success: false,
        message: 'Trip not found'
      });
    }

    res.status(200).json({
      success: true,
      data: trip
    });
  } catch (error) {
    next(error);
  }
};

// @desc Update trip
// @route PUT /api/trips/:id
// @access Private
exports.updateTrip = async (req, res, next) => {
  try {
    let trip = await TripTracking.findById(req.params.id);

    if (!trip) {
      return res.status(404).json({
        success: false,
        message: 'Trip not found'
      });
    }

    trip = await TripTracking.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate('busId sourceStation destinationStation');

    res.status(200).json({
      success: true,
      message: 'Trip updated successfully',
      data: trip
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get trip history for a bus
// @route GET /api/trips/bus/:busId
// @access Private
exports.getTripHistory = async (req, res, next) => {
  try {
    const { limit = 20 } = req.query;
    const trips = await tripService.getTripHistory(req.params.busId, parseInt(limit));

    res.status(200).json({
      success: true,
      count: trips.length,
      data: trips
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get active trip for a bus
// @route GET /api/trips/bus/:busId/active
// @access Private
exports.getActiveTripForBus = async (req, res, next) => {
  try {
    const trip = await tripService.getActiveTripForBus(req.params.busId);

    res.status(200).json({
      success: !!trip,
      data: trip
    });
  } catch (error) {
    next(error);
  }
};

// @desc Cancel trip
// @route PUT /api/trips/:id/cancel
// @access Private
exports.cancelTrip = async (req, res, next) => {
  try {
    const trip = await TripTracking.findByIdAndUpdate(
      req.params.id,
      { status: constants.TRIP_STATUS.CANCELLED },
      { new: true }
    ).populate('busId sourceStation destinationStation');

    if (!trip) {
      return res.status(404).json({
        success: false,
        message: 'Trip not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Trip cancelled successfully',
      data: trip
    });
  } catch (error) {
    next(error);
  }
};
