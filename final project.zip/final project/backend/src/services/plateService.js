const geoFenceService = require('./geoFenceService');
const ManualPlateEntry = require('../models/ManualPlateEntry');
const Bus = require('../models/Bus');
const TripTracking = require('../models/TripTracking');
const constants = require('../config/constants');

const plateService = {
  // Match plate with bus and verify
  matchPlateWithBus: async (plateNumber, stationId, enteredByUser) => {
    try {
      // Find bus by registration number
      const bus = await Bus.findOne({ 
        registrationNumber: plateNumber.toUpperCase(),
        status: constants.BUS_STATUS.ACTIVE 
      });

      if (!bus) {
        return {
          matched: false,
          message: 'Bus not found with this registration number'
        };
      }

      // Get latest GPS location
      const GPSLocation = require('../models/GPSLocation');
      const latestLocation = await GPSLocation.findOne({ busId: bus._id })
        .sort({ timestamp: -1 });

      if (!latestLocation) {
        return {
          matched: false,
          bus,
          message: 'No GPS location found for this bus'
        };
      }

      // Check if bus is in geofence
      const geofenceData = await geoFenceService.checkBusInGeofence(
        bus._id,
        latestLocation.latitude,
        latestLocation.longitude
      );

      // Create plate entry record
      const plateEntry = new ManualPlateEntry({
        stationId,
        capturedNumberPlate: plateNumber.toUpperCase(),
        entryTime: new Date(),
        matchedBusId: bus._id,
        enteredBy: enteredByUser,
        status: geofenceData.inGeofence ? constants.PLATE_STATUS.AUTO_MATCHED : constants.PLATE_STATUS.PENDING,
        gpsMatchDetails: {
          busLatitude: latestLocation.latitude,
          busLongitude: latestLocation.longitude,
          distanceFromStation: geofenceData.distance,
          withinGeofence: geofenceData.inGeofence
        }
      });

      // If in geofence, auto-match with trip
      if (geofenceData.inGeofence && geofenceData.stationId) {
        const activeTrip = await TripTracking.findOne({
          busId: bus._id,
          status: { $in: [constants.TRIP_STATUS.DEPARTED, constants.TRIP_STATUS.IN_TRANSIT] }
        }).sort({ departureTime: -1 });

        if (activeTrip) {
          plateEntry.matchedTripId = activeTrip._id;
          
          // Check if this is destination station
          if (activeTrip.destinationStation.toString() === geofenceData.stationId.toString()) {
            plateEntry.status = constants.PLATE_STATUS.VERIFIED;
            
            // Update trip status
            activeTrip.status = constants.TRIP_STATUS.ARRIVED;
            activeTrip.actualArrivalTime = new Date();
            activeTrip.numberPlateVerification = {
              capturedAt: new Date(),
              recognizedPlate: plateNumber.toUpperCase(),
              manualConfirmed: true,
              confirmedBy: enteredByUser,
              gpsLocationMatch: true,
              matchScore: 100
            };
            
            await activeTrip.save();
          }
        }
      }

      await plateEntry.save();

      return {
        matched: true,
        bus,
        plateEntry: plateEntry._id,
        inGeofence: geofenceData.inGeofence,
        distance: geofenceData.distance,
        message: geofenceData.inGeofence ? 'Bus matched and in geofence' : 'Bus matched but not in geofence'
      };
    } catch (error) {
      console.error('Plate matching error:', error);
      throw error;
    }
  },

  // Verify/confirm a plate entry
  verifyPlateEntry: async (plateEntryId, verified, userId, notes = null) => {
    try {
      const plateEntry = await ManualPlateEntry.findById(plateEntryId);

      if (!plateEntry) {
        throw new Error('Plate entry not found');
      }

      plateEntry.status = verified ? constants.PLATE_STATUS.VERIFIED : constants.PLATE_STATUS.REJECTED;
      plateEntry.verifiedBy = userId;
      plateEntry.verificationNotes = notes;

      if (verified && plateEntry.matchedTripId) {
        const trip = await TripTracking.findById(plateEntry.matchedTripId);
        if (trip) {
          trip.numberPlateVerification.manualConfirmed = true;
          trip.numberPlateVerification.confirmedBy = userId;
          await trip.save();
        }
      }

      await plateEntry.save();
      return plateEntry;
    } catch (error) {
      console.error('Plate verification error:', error);
      throw error;
    }
  }
};

module.exports = plateService;
