const mongoose = require('mongoose');

const busStationSchema = new mongoose.Schema(
  {
    stationId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true
    },
    stationName: {
      type: String,
      required: true,
      trim: true
    },
    city: {
      type: String,
      required: true,
      trim: true
    },
    address: {
      type: String,
      default: null
    },
    latitude: {
      type: Number,
      required: true
    },
    longitude: {
      type: Number,
      required: true
    },
    geofenceRadiusMeters: {
      type: Number,
      default: 200,
      min: 50,
      max: 1000
    },
    entranceCamera: {
      cameraId: {
        type: String,
        default: null
      },
      status: {
        type: String,
        enum: ['active', 'inactive'],
        default: 'inactive'
      }
    },
    contactNumber: {
      type: String,
      default: null
    },
    manager: {
      type: String,
      default: null
    },
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active'
    }
  },
  {
    timestamps: true
  }
);

// Geospatial index for location-based queries
busStationSchema.index({ latitude: 1, longitude: 1 });

module.exports = mongoose.model('BusStation', busStationSchema);
