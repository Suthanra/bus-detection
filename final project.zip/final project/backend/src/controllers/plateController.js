const plateService = require('../services/plateService');
const ManualPlateEntry = require('../models/ManualPlateEntry');
const Bus = require('../models/Bus');

// @desc Create manual plate entry
// @route POST /api/plates
// @access Private
exports.createPlateEntry = async (req, res, next) => {
  try {
    const { numberPlate, stationId } = req.body;

    // Match plate with bus
    const result = await plateService.matchPlateWithBus(
      numberPlate,
      stationId,
      req.user._id
    );

    res.status(201).json({
      success: result.matched,
      message: result.message,
      data: result
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get all plate entries
// @route GET /api/plates
// @access Private
exports.getAllPlateEntries = async (req, res, next) => {
  try {
    const { status, stationId, limit = 50 } = req.query;
    
    let query = {};
    if (status) query.status = status;
    if (stationId) query.stationId = stationId;

    const entries = await ManualPlateEntry.find(query)
      .populate('matchedBusId stationId enteredBy verifiedBy')
      .sort({ entryTime: -1 })
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: entries.length,
      data: entries
    });
  } catch (error) {
    next(error);
  }
};

// @desc Get single plate entry
// @route GET /api/plates/:id
// @access Private
exports.getPlateEntryById = async (req, res, next) => {
  try {
    const entry = await ManualPlateEntry.findById(req.params.id)
      .populate('matchedBusId stationId enteredBy verifiedBy matchedTripId');

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Plate entry not found'
      });
    }

    res.status(200).json({
      success: true,
      data: entry
    });
  } catch (error) {
    next(error);
  }
};

// @desc Update plate entry (modify number plate or details)
// @route PUT /api/plates/:id
// @access Private
exports.updatePlateEntry = async (req, res, next) => {
  try {
    const { numberPlate, stationId, notes } = req.body;

    let entry = await ManualPlateEntry.findById(req.params.id);

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Plate entry not found'
      });
    }

    // If number plate is being changed, re-match it
    if (numberPlate && numberPlate !== entry.capturedNumberPlate) {
      const matchResult = await plateService.matchPlateWithBus(
        numberPlate,
        stationId || entry.stationId,
        req.user._id
      );

      entry.capturedNumberPlate = numberPlate.toUpperCase();
      entry.matchedBusId = matchResult.bus ? matchResult.bus._id : null;
      entry.gpsMatchDetails = matchResult.bus ? {
        distanceFromStation: matchResult.distance,
        withinGeofence: matchResult.inGeofence
      } : {};
    }

    if (notes) {
      entry.verificationNotes = notes;
    }

    await entry.save();
    await entry.populate('matchedBusId stationId enteredBy verifiedBy');

    res.status(200).json({
      success: true,
      message: 'Plate entry updated successfully',
      data: entry
    });
  } catch (error) {
    next(error);
  }
};

// @desc Delete plate entry
// @route DELETE /api/plates/:id
// @access Private (Admin)
exports.deletePlateEntry = async (req, res, next) => {
  try {
    const entry = await ManualPlateEntry.findByIdAndDelete(req.params.id);

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Plate entry not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Plate entry deleted successfully',
      data: entry
    });
  } catch (error) {
    next(error);
  }
};

// @desc Verify/confirm plate entry
// @route POST /api/plates/:id/verify
// @access Private
exports.verifyPlateEntry = async (req, res, next) => {
  try {
    const { verified, notes } = req.body;

    const entry = await plateService.verifyPlateEntry(
      req.params.id,
      verified,
      req.user._id,
      notes
    );

    res.status(200).json({
      success: true,
      message: `Plate entry ${verified ? 'verified' : 'rejected'} successfully`,
      data: entry
    });
  } catch (error) {
    next(error);
  }
};

// @desc Search plates by number
// @route GET /api/plates/search/:plateNumber
// @access Private
exports.searchPlateByNumber = async (req, res, next) => {
  try {
    const entries = await ManualPlateEntry.find({
      capturedNumberPlate: req.params.plateNumber.toUpperCase()
    })
      .populate('matchedBusId stationId')
      .sort({ entryTime: -1 });

    res.status(200).json({
      success: true,
      count: entries.length,
      data: entries
    });
  } catch (error) {
    next(error);
  }
};
