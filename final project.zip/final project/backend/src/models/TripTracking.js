const mongoose = require('mongoose');

const tripTrackingSchema = new mongoose.Schema(
  {
    tripId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    busId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bus',
      required: true,
      index: true
    },
    sourceConductor: {
      type: String,
      required: true,
      trim: true
    },
    sourceStation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'BusStation',
      required: true
    },
    destinationStation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'BusStation',
      required: true
    },
    departureTime: {
      type: Date,
      required: true
    },
    estimatedArrivalTime: {
      type: Date,
      default: null
    },
    actualArrivalTime: {
      type: Date,
      default: null
    },
    status: {
      type: String,
      enum: ['scheduled', 'departed', 'in-transit', 'arrived', 'cancelled'],
      default: 'scheduled'
    },
    numberPlateVerification: {
      capturedAt: {
        type: Date,
        default: null
      },
      recognizedPlate: {
        type: String,
        trim: true,
        uppercase: true,
        default: null
      },
      manualConfirmed: {
        type: Boolean,
        default: false
      },
      confirmedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null
      },
      gpsLocationMatch: {
        type: Boolean,
        default: false
      },
      matchScore: {
        type: Number,
        min: 0,
        max: 100,
        default: 0
      }
    },
    gpsArrivalConfirmation: {
      confirmedAt: {
        type: Date,
        default: null
      },
      latitude: {
        type: Number,
        default: null
      },
      longitude: {
        type: Number,
        default: null
      },
      distance: {
        type: Number,
        default: null // in meters
      }
    },
    notes: {
      type: String,
      default: null
    }
  },
  {
    timestamps: true
  }
);

// Indexes for efficient queries
tripTrackingSchema.index({ busId: 1, departureTime: -1 });
tripTrackingSchema.index({ status: 1 });
tripTrackingSchema.index({ createdAt: -1 });

module.exports = mongoose.model('TripTracking', tripTrackingSchema);
