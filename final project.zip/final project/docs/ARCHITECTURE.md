# Bus Tracking System - Architecture & Design

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    BUS TRACKING SYSTEM                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                 ┌────────────┼────────────┐
                 │            │            │
            ┌────▼────┐  ┌────▼─────┐  ┌─▼──────────┐
            │ Frontend │  │ Backend  │  │  Database  │
            │ (React)  │  │(Express) │  │ (MongoDB)  │
            └─────────┘  └──────────┘  └────────────┘
```

## Component Architecture

### Frontend Architecture
```
App.jsx (Router)
├── PublicPages
│   ├── Login
│   └── Register
├── ProtectedRoutes
│   ├── Dashboard
│   │   └── AdminDashboard
│   ├── BusManagement
│   │   └── BusList
│   ├── StationManagement
│   │   └── StationList
│   ├── TripTracking
│   │   └── TripList
│   ├── NumberPlate
│   │   └── PlateVerification
│   └── Map
│       └── LiveMap
└── Common
    └── Sidebar (Navigation)

Services:
├── api.js (Axios instance)
├── socketService.js (Socket.io)
└── apiServices.js (CRUD operations)

State Management:
└── Zustand Store
    ├── useAuthStore
    ├── useMapStore
    └── useTripStore
```

### Backend Architecture
```
Server (Node.js)
├── Express App
│   ├── Middlewares
│   │   ├── authMiddleware
│   │   ├── errorHandler
│   │   └── validationMiddleware
│   ├── Routes
│   │   ├── authRoutes
│   │   ├── busRoutes
│   │   ├── gpsRoutes
│   │   ├── stationRoutes
│   │   ├── tripRoutes
│   │   └── plateRoutes
│   ├── Controllers
│   │   ├── authController
│   │   ├── busController
│   │   ├── gpsController
│   │   ├── stationController
│   │   ├── tripController
│   │   └── plateController
│   ├── Services
│   │   ├── geoFenceService
│   │   ├── tripService
│   │   ├── plateService
│   │   └── googleMapsService
│   └── Models
│       ├── Bus
│       ├── GPSLocation
│       ├── BusStation
│       ├── TripTracking
│       ├── ManualPlateEntry
│       └── User
├── Socket.io Handler
├── Background Jobs
│   ├── geofenceCheckJob (every 5 min)
│   └── gpsCleanupJob (daily)
└── Database (MongoDB)
```

## Data Flow Diagrams

### GPS Tracking Flow
```
Conductor Mobile App
        │
        │ (GPS coordinates every 5 min)
        ▼
POST /api/gps/update
        │
        ├────────────────────────┐
        │                        │
        ▼                        ▼
Store in MongoDB         Check Geofence
        │                        │
        ├────────────────────────┤
        │                        │
        ▼                        ▼
Update Bus Location      If within 200m
        │                       │
        └───────────┬───────────┘
                    │
                    ▼
            Emit Socket.io Event
                    │
                    ▼
        Real-time Map Update
```

### Number Plate Verification Flow
```
Bus Stand Camera/Admin
        │
        │ (Plate Number)
        ▼
POST /api/plates
        │
        ├──────────────────────────┐
        │                          │
        ▼                          ▼
Search Bus by Number    Get Latest GPS
        │                          │
        ├──────────────────────────┤
        │                          │
        ▼                          ▼
Found?                  Within Geofence?
        │                          │
   Yes/No                     Yes/No
        │                          │
        └───────────┬──────────────┘
                    │
                    ▼
        Store ManualPlateEntry
                    │
        ┌───────────┴───────────┐
        │                       │
        ▼                       ▼
    Auto-matched          Mark Pending
    (verified=true)     (needs verification)
        │                       │
        └───────────┬───────────┘
                    │
                    ▼
        Update Trip Status
                    │
                    ▼
        Emit plate-verified Event
```

### Trip Lifecycle
```
Create Trip
    │
    ├─ Status: SCHEDULED
    │
    ▼
Conductor Departs
    │
    ├─ Status: DEPARTED
    │
    ▼
GPS Updates Received
    │
    ├─ Check Geofence Every 5 min
    │
    ▼
Bus Enters Geofence
    │
    ├─ Status: IN_TRANSIT
    │
    ▼
Bus Reaches Destination Station
    │
    ├─ Status: ARRIVED
    │ (after plate verification)
    │
    ▼
Trip Complete
```

## Database Schema Relationships

```
User (1) ─────────────────────────── (many) TripTracking
         ─────────────────────────── (many) ManualPlateEntry

Bus (1) ─────────────────────────── (many) GPSLocation
    │                             
    └─ (many) TripTracking
    └─ (many) ManualPlateEntry

BusStation (1) ─────────────────────────── (many) TripTracking
           │                            
           └─ (many) ManualPlateEntry

TripTracking (1) ─────────────────────────── (many) Events (Socket.io)
```

## Request/Response Flow

### Typical API Request
```
1. Frontend (React)
   ↓ (axios instance with JWT)
2. Backend (Express)
   ↓ (authMiddleware - verify token)
3. Validation
   ↓ (check input data)
4. Controller
   ↓ (business logic)
5. Service
   ↓ (complex operations)
6. Database (MongoDB)
   ↓ (CRUD operations)
7. Response
   ↓ (error handling)
8. Frontend (React)
   ↓ (update UI/store)
9. Socket.io (optional)
   ↓ (real-time updates)
10. All Connected Clients
```

## Real-time Communication

### Socket.io Events
```
Client Side              Server Side              All Clients
───────────              ───────────              ──────────
connect()                                            update
    │
    ├─ join 'bus-BUS001'  ────────→ socketHandler
    │                               │
    │                      emit 'bus-location-update'
    │                               │
    │◄─────────────────────────────┤
    │
    ├─ track-bus-location ────────→ Store update
    │
    └─ stop-tracking-bus ───────→ Leave room
```

## Scalability Considerations

### Current Capacity
- **Buses**: 10 (easily scalable to 100+)
- **Concurrent Users**: 50-100 (with Socket.io)
- **API Requests**: 100+ per second
- **Database**: Supports millions of GPS records

### Scaling Strategy
1. **Horizontal Scaling**
   - Multiple backend instances
   - Load balancer (Nginx)
   - Shared MongoDB

2. **Database Optimization**
   - Indexes on frequently queried fields
   - TTL indexes for automatic cleanup
   - Sharding for large datasets

3. **Caching Layer**
   - Redis for session management
   - Cache bus locations
   - Cache trip data

4. **Microservices**
   - GPS service
   - Trip service
   - Notification service
   - Analytics service

## Security Architecture

### Authentication Flow
```
Login Request
      │
      ▼
Validate Credentials
      │
      ▼
Generate JWT Token
      │
      ├─ Payload: userId, role
      ├─ Signature: SECRET
      └─ Expiry: 7 days
      │
      ▼
Store in Local Storage
      │
      ▼
Include in API Requests
      │
      ├─ Authorization: Bearer <token>
      │
      ▼
Verify Token + Check Role
      │
      ▼
Grant Access
```

## Error Handling

### Error Flow
```
Request
    │
    ▼
Try Block
    │
    ├─ Success? → Return 200/201
    │
    └─ Error? → Catch Block
              │
              ├─ Validation Error → 400
              ├─ Auth Error → 401
              ├─ Not Found → 404
              ├─ Duplicate → 400
              └─ Server Error → 500
              │
              ▼
        Return Error Response
              │
              ▼
        Frontend Toast Notification
```

## Performance Optimization

### Frontend
- Code splitting with Vite
- Lazy loading routes
- Memoization of components
- Local storage for auth token

### Backend
- Database indexing
- Connection pooling
- Response compression
- Caching strategies

### Database
- TTL indexes for auto-cleanup
- Aggregate pipelines for complex queries
- Batch operations
- Query optimization

## Deployment Architecture

### Development
```
Local Machine
├── Frontend (Vite Dev Server)
├── Backend (Express + Nodemon)
└── MongoDB (Local)
```

### Production
```
Server/Cloud
├── Docker Container 1 (Frontend - Nginx)
├── Docker Container 2 (Backend - Node.js)
└── Docker Container 3 (MongoDB)
    (All managed by Docker Compose)
```

## Monitoring & Logging

### Logs Generated
- API request/response
- Database queries
- Authentication events
- Geofence detections
- Job execution
- Socket.io connections

### Monitoring Points
- Server health check
- Database connections
- Socket.io connections
- API response times
- Error rates

This architecture is designed for:
- ✅ Scalability
- ✅ Maintainability
- ✅ Real-time updates
- ✅ Security
- ✅ Performance
- ✅ Easy deployment

