import React from 'react';
import { useAuthStore } from '../../utils/store';

export default function AdminDashboard() {
  const { user } = useAuthStore();

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-lg shadow p-8">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user?.firstName || user?.username}!</h1>
        <p className="text-blue-100">Bus Tracking System - Admin Dashboard</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Active Buses" value="10" color="blue" />
        <StatCard title="Pending Verifications" value="5" color="yellow" />
        <StatCard title="Completed Trips" value="48" color="green" />
        <StatCard title="System Status" value="Online" color="green" />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <action-button>Add New Bus</action-button>
          <action-button>Create Trip</action-button>
          <action-button>Verify Plates</action-button>
          <action-button>View Reports</action-button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
        <div className="space-y-3">
          <ActivityItem time="2 hours ago" message="Bus BUS001 arrived at Central Station" />
          <ActivityItem time="4 hours ago" message="New plate entry created for MH-01-AB-1234" />
          <ActivityItem time="1 day ago" message="Trip TRIP001 completed successfully" />
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, color }) {
  const bgColors = {
    blue: 'bg-blue-50 border-blue-200',
    green: 'bg-green-50 border-green-200',
    yellow: 'bg-yellow-50 border-yellow-200',
    red: 'bg-red-50 border-red-200'
  };

  const textColors = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    yellow: 'text-yellow-600',
    red: 'text-red-600'
  };

  return (
    <div className={`${bgColors[color]} border rounded-lg p-6`}>
      <p className="text-gray-600 text-sm mb-1">{title}</p>
      <p className={`${textColors[color]} text-3xl font-bold`}>{value}</p>
    </div>
  );
}

function ActivityItem({ time, message }) {
  return (
    <div className="flex gap-4 pb-3 border-b last:border-b-0">
      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
      <div>
        <p className="font-medium text-gray-800">{message}</p>
        <p className="text-sm text-gray-500">{time}</p>
      </div>
    </div>
  );
}
