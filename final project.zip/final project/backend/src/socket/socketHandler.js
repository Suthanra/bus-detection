const socketHandler = (io) => {
  io.on('connection', (socket) => {
    console.log('New client connected:', socket.id);

    // Handle bus location updates
    socket.on('bus-location-update', (data) => {
      console.log('Location update received:', data);
      
      // Broadcast to all connected clients
      io.emit('bus-location-update', data);
    });

    // Handle real-time map tracking
    socket.on('start-tracking-bus', (busId) => {
      console.log('Client tracking bus:', busId);
      socket.join(`bus-${busId}`);
    });

    socket.on('stop-tracking-bus', (busId) => {
      console.log('Client stopped tracking bus:', busId);
      socket.leave(`bus-${busId}`);
    });

    // Handle trip updates
    socket.on('trip-update', (data) => {
      io.emit('trip-update', data);
    });

    // Handle plate verification
    socket.on('plate-verified', (data) => {
      io.emit('plate-verified', data);
    });

    // Handle disconnection
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });

    // Send initial connection message
    socket.emit('connection', {
      message: 'Connected to Bus Tracking Server',
      timestamp: new Date()
    });
  });
};

module.exports = socketHandler;
