const TripTracking = require('../models/TripTracking');
const Bus = require('../models/Bus');
const BusStation = require('../models/BusStation');
const constants = require('../config/constants');
const geoFenceService = require('./geoFenceService');

const tripService = {
  // Create a new trip
  createTrip: async (tripData) => {
    try {
      const trip = new TripTracking(tripData);
      await trip.save();
      return trip.populate('busId sourceStation destinationStation');
    } catch (error) {
      console.error('Trip creation error:', error);
      throw error;
    }
  },

  // Update trip status based on geofence detection
  updateTripStatusByGeofence: async (busId, stationId) => {
    try {
      const activeTrip = await TripTracking.findOne({
        busId,
        status: { $in: [constants.TRIP_STATUS.DEPARTED, constants.TRIP_STATUS.IN_TRANSIT] }
      }).sort({ departureTime: -1 });

      if (!activeTrip) {
        return null;
      }

      // Check if this is the destination station
      const isFinalDestination = activeTrip.destinationStation.toString() === stationId.toString();

      if (isFinalDestination) {
        activeTrip.status = constants.TRIP_STATUS.ARRIVED;
        activeTrip.actualArrivalTime = new Date();
        activeTrip.gpsArrivalConfirmation = {
          confirmedAt: new Date()
        };
      } else {
        activeTrip.status = constants.TRIP_STATUS.IN_TRANSIT;
      }

      await activeTrip.save();
      return activeTrip;
    } catch (error) {
      console.error('Trip status update error:', error);
      throw error;
    }
  },

  // Get trip history for a bus
  getTripHistory: async (busId, limit = 10) => {
    try {
      const trips = await TripTracking.find({ busId })
        .populate('sourceStation destinationStation')
        .sort({ departureTime: -1 })
        .limit(limit);

      return trips;
    } catch (error) {
      console.error('Trip history error:', error);
      throw error;
    }
  },

  // Get active trip for a bus
  getActiveTripForBus: async (busId) => {
    try {
      const trip = await TripTracking.findOne({
        busId,
        status: { $in: [constants.TRIP_STATUS.SCHEDULED, constants.TRIP_STATUS.DEPARTED, constants.TRIP_STATUS.IN_TRANSIT] }
      }).sort({ departureTime: -1 });

      return trip;
    } catch (error) {
      console.error('Active trip error:', error);
      throw error;
    }
  }
};

module.exports = tripService;
