import axiosInstance from './api';

const authService = {
  register: async (userData) => {
    const response = await axiosInstance.post('/auth/register', userData);
    if (response.data.token) {
      localStorage.setItem('authToken', response.data.token);
    }
    return response.data;
  },

  login: async (username, password) => {
    const response = await axiosInstance.post('/auth/login', { username, password });
    if (response.data.token) {
      localStorage.setItem('authToken', response.data.token);
    }
    return response.data;
  },

  logout: () => {
    localStorage.removeItem('authToken');
  },

  getCurrentUser: async () => {
    const response = await axiosInstance.get('/auth/me');
    return response.data;
  }
};

export const busService = {
  getAllBuses: async () => {
    const response = await axiosInstance.get('/buses');
    return response.data;
  },

  getBusById: async (id) => {
    const response = await axiosInstance.get(`/buses/${id}`);
    return response.data;
  },

  createBus: async (busData) => {
    const response = await axiosInstance.post('/buses', busData);
    return response.data;
  },

  updateBus: async (id, busData) => {
    const response = await axiosInstance.put(`/buses/${id}`, busData);
    return response.data;
  },

  deleteBus: async (id) => {
    const response = await axiosInstance.delete(`/buses/${id}`);
    return response.data;
  }
};

export const gpsService = {
  submitLocation: async (gpsData) => {
    const response = await axiosInstance.post('/gps/update', gpsData);
    return response.data;
  },

  getLatestLocation: async (busId) => {
    const response = await axiosInstance.get(`/gps/bus/${busId}/latest`);
    return response.data;
  },

  getLocationHistory: async (busId, days = 1, limit = 100) => {
    const response = await axiosInstance.get(`/gps/bus/${busId}/history`, {
      params: { days, limit }
    });
    return response.data;
  },

  getAllCurrentLocations: async () => {
    const response = await axiosInstance.get('/gps/all/current');
    return response.data;
  }
};

export const stationService = {
  getAllStations: async () => {
    const response = await axiosInstance.get('/stations');
    return response.data;
  },

  getStationById: async (id) => {
    const response = await axiosInstance.get(`/stations/${id}`);
    return response.data;
  },

  createStation: async (stationData) => {
    const response = await axiosInstance.post('/stations', stationData);
    return response.data;
  },

  updateStation: async (id, stationData) => {
    const response = await axiosInstance.put(`/stations/${id}`, stationData);
    return response.data;
  },

  deleteStation: async (id) => {
    const response = await axiosInstance.delete(`/stations/${id}`);
    return response.data;
  }
};

export const tripService = {
  getAllTrips: async (status = null, limit = 50) => {
    const response = await axiosInstance.get('/trips', {
      params: { status, limit }
    });
    return response.data;
  },

  getTripById: async (id) => {
    const response = await axiosInstance.get(`/trips/${id}`);
    return response.data;
  },

  createTrip: async (tripData) => {
    const response = await axiosInstance.post('/trips', tripData);
    return response.data;
  },

  updateTrip: async (id, tripData) => {
    const response = await axiosInstance.put(`/trips/${id}`, tripData);
    return response.data;
  },

  cancelTrip: async (id) => {
    const response = await axiosInstance.put(`/trips/${id}/cancel`);
    return response.data;
  },

  getTripHistory: async (busId, limit = 20) => {
    const response = await axiosInstance.get(`/trips/bus/${busId}/history`, {
      params: { limit }
    });
    return response.data;
  }
};

export const plateService = {
  createPlateEntry: async (plateData) => {
    const response = await axiosInstance.post('/plates', plateData);
    return response.data;
  },

  getAllPlateEntries: async (status = null, stationId = null, limit = 50) => {
    const response = await axiosInstance.get('/plates', {
      params: { status, stationId, limit }
    });
    return response.data;
  },

  getPlateEntryById: async (id) => {
    const response = await axiosInstance.get(`/plates/${id}`);
    return response.data;
  },

  updatePlateEntry: async (id, plateData) => {
    const response = await axiosInstance.put(`/plates/${id}`, plateData);
    return response.data;
  },

  deletePlateEntry: async (id) => {
    const response = await axiosInstance.delete(`/plates/${id}`);
    return response.data;
  },

  verifyPlateEntry: async (id, verified, notes = null) => {
    const response = await axiosInstance.post(`/plates/${id}/verify`, {
      verified,
      notes
    });
    return response.data;
  },

  searchPlateByNumber: async (plateNumber) => {
    const response = await axiosInstance.get(`/plates/search/${plateNumber}`);
    return response.data;
  }
};

export default authService;
