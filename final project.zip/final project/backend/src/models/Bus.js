const mongoose = require('mongoose');

const busSchema = new mongoose.Schema(
  {
    busId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true
    },
    registrationNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true
    },
    driverName: {
      type: String,
      required: true,
      trim: true
    },
    conductorName: {
      type: String,
      required: true,
      trim: true
    },
    conductorPhone: {
      type: String,
      required: true,
      trim: true
    },
    busType: {
      type: String,
      enum: ['AC', 'Non-AC', 'Sleeper', 'Semi-Sleeper'],
      default: 'AC'
    },
    capacity: {
      type: Number,
      required: true,
      min: 1,
      max: 100
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'maintenance'],
      default: 'active'
    },
    lastLocationUpdate: {
      type: Date,
      default: null
    },
    currentLocation: {
      latitude: {
        type: Number,
        default: null
      },
      longitude: {
        type: Number,
        default: null
      }
    }
  },
  {
    timestamps: true
  }
);

// Index for faster queries
busSchema.index({ registrationNumber: 1 });
busSchema.index({ status: 1 });

module.exports = mongoose.model('Bus', busSchema);
