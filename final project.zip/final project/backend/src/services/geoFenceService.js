const googleMapsService = require('../config/googleMaps');
const BusStation = require('../models/BusStation');
const constants = require('../config/constants');

const geoFenceService = {
  // Check if bus is within geofence of any station
  checkBusInGeofence: async (busId, latitude, longitude) => {
    try {
      const stations = await BusStation.find({ status: 'active' });

      for (const station of stations) {
        const distance = googleMapsService.calculateDistance(
          latitude,
          longitude,
          station.latitude,
          station.longitude
        );

        if (distance <= station.geofenceRadiusMeters) {
          return {
            inGeofence: true,
            stationId: station._id,
            stationName: station.stationName,
            distance
          };
        }
      }

      return {
        inGeofence: false,
        stationId: null,
        distance: null
      };
    } catch (error) {
      console.error('Geofence check error:', error);
      throw error;
    }
  },

  // Check if two locations are within a certain distance
  isWithinDistance: (lat1, lon1, lat2, lon2, distanceMeters) => {
    const distance = googleMapsService.calculateDistance(lat1, lon1, lat2, lon2);
    return distance <= distanceMeters;
  },

  // Get all stations within a radius
  getNearbyStations: async (latitude, longitude, radiusMeters = 5000) => {
    try {
      const stations = await BusStation.find({ status: 'active' });
      const nearbyStations = [];

      for (const station of stations) {
        const distance = googleMapsService.calculateDistance(
          latitude,
          longitude,
          station.latitude,
          station.longitude
        );

        if (distance <= radiusMeters) {
          nearbyStations.push({
            stationId: station._id,
            stationName: station.stationName,
            distance
          });
        }
      }

      return nearbyStations.sort((a, b) => a.distance - b.distance);
    } catch (error) {
      console.error('Nearby stations error:', error);
      throw error;
    }
  }
};

module.exports = geoFenceService;
