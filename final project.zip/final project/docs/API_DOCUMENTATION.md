# Bus Tracking System - API Documentation

## Overview
RESTful API for real-time bus tracking system with GPS monitoring, automatic number plate recognition, and trip management.

## Base URL
```
http://localhost:5000/api
```

## Authentication
All endpoints (except `/auth/register` and `/auth/login`) require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

## Authentication Endpoints

### Register User
```
POST /auth/register
Content-Type: application/json

{
  "userId": "USER001",
  "username": "john_doe",
  "email": "john@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "admin"
}

Response:
{
  "success": true,
  "message": "User registered successfully",
  "token": "jwt_token_here",
  "data": { user object }
}
```

### Login
```
POST /auth/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "password123"
}

Response:
{
  "success": true,
  "message": "Login successful",
  "token": "jwt_token_here",
  "data": { user object }
}
```

### Get Current User
```
GET /auth/me
Authorization: Bearer <token>

Response:
{
  "success": true,
  "data": { user object }
}
```

## Bus Endpoints

### Get All Buses
```
GET /buses

Response:
{
  "success": true,
  "count": 10,
  "data": [{ bus objects }]
}
```

### Get Single Bus
```
GET /buses/:id

Response:
{
  "success": true,
  "data": { bus object }
}
```

### Create Bus
```
POST /buses
Content-Type: application/json

{
  "busId": "BUS001",
  "registrationNumber": "MH-01-AB-1234",
  "driverName": "John Driver",
  "conductorName": "Jane Conductor",
  "conductorPhone": "9876543210",
  "busType": "AC",
  "capacity": 50,
  "status": "active"
}
```

### Update Bus
```
PUT /buses/:id
Content-Type: application/json

{ same fields as create }
```

### Delete Bus
```
DELETE /buses/:id
```

## GPS Endpoints

### Submit GPS Location
```
POST /gps/update
Content-Type: application/json

{
  "busId": "bus_id",
  "latitude": 19.0760,
  "longitude": 72.8777,
  "accuracy": 10,
  "speed": 45,
  "direction": 270
}

Response:
{
  "success": true,
  "message": "GPS location recorded",
  "data": {
    "gpsLocation": { location object },
    "geofence": {
      "inGeofence": true,
      "stationId": "station_id",
      "stationName": "Central Station",
      "distance": 150
    }
  }
}
```

### Get Latest Location
```
GET /gps/bus/:busId/latest

Response:
{
  "success": true,
  "data": { location object }
}
```

### Get Location History
```
GET /gps/bus/:busId/history?days=1&limit=100

Response:
{
  "success": true,
  "count": 50,
  "data": [{ location objects }]
}
```

### Get All Current Locations
```
GET /gps/all/current

Response:
{
  "success": true,
  "count": 10,
  "data": [
    {
      "bus": { bus object },
      "location": { location object }
    }
  ]
}
```

## Station Endpoints

### Get All Stations
```
GET /stations

Response:
{
  "success": true,
  "count": 5,
  "data": [{ station objects }]
}
```

### Create Station
```
POST /stations
Content-Type: application/json

{
  "stationId": "STN001",
  "stationName": "Central Bus Stand",
  "city": "Mumbai",
  "address": "Main Street",
  "latitude": 19.0760,
  "longitude": 72.8777,
  "geofenceRadiusMeters": 200,
  "contactNumber": "9876543210",
  "manager": "Manager Name",
  "status": "active"
}
```

### Update Station
```
PUT /stations/:id
Content-Type: application/json

{ same fields as create }
```

### Delete Station
```
DELETE /stations/:id
```

## Trip Endpoints

### Create Trip
```
POST /trips
Content-Type: application/json

{
  "tripId": "TRIP001",
  "busId": "bus_id",
  "sourceConductor": "Jane Conductor",
  "sourceStation": "station_id",
  "destinationStation": "station_id",
  "departureTime": "2024-01-20T10:00:00Z",
  "estimatedArrivalTime": "2024-01-20T12:00:00Z"
}
```

### Get All Trips
```
GET /trips?status=in-transit&limit=50

Response:
{
  "success": true,
  "count": 10,
  "data": [{ trip objects }]
}
```

### Get Trip by ID
```
GET /trips/:id
```

### Update Trip
```
PUT /trips/:id
Content-Type: application/json

{ trip fields }
```

### Get Trip History for Bus
```
GET /trips/bus/:busId/history?limit=20
```

### Get Active Trip for Bus
```
GET /trips/bus/:busId/active
```

### Cancel Trip
```
PUT /trips/:id/cancel
```

## Number Plate Endpoints

### Create Plate Entry
```
POST /plates
Content-Type: application/json

{
  "numberPlate": "MH-01-AB-1234",
  "stationId": "station_id"
}

Response:
{
  "success": true,
  "message": "Plate matched and verified",
  "data": {
    "matched": true,
    "bus": { bus object },
    "plateEntry": "entry_id",
    "inGeofence": true,
    "distance": 150
  }
}
```

### Get All Plate Entries
```
GET /plates?status=pending&stationId=station_id&limit=50

Response:
{
  "success": true,
  "count": 10,
  "data": [{ plate entry objects }]
}
```

### Get Plate Entry by ID
```
GET /plates/:id
```

### Update Plate Entry
```
PUT /plates/:id
Content-Type: application/json

{
  "numberPlate": "MH-01-AB-1234",
  "stationId": "station_id",
  "notes": "Some notes"
}
```

### Verify Plate Entry
```
POST /plates/:id/verify
Content-Type: application/json

{
  "verified": true,
  "notes": "Verified successfully"
}
```

### Delete Plate Entry
```
DELETE /plates/:id
```

### Search Plate by Number
```
GET /plates/search/:plateNumber
```

## Error Handling

All errors return appropriate HTTP status codes with error details:

```
{
  "success": false,
  "message": "Error message",
  "error": "Detailed error information"
}
```

Common status codes:
- 200: OK
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 404: Not Found
- 500: Internal Server Error

## Socket.io Events

### Bus Location Update
```
io.on('bus-location-update', (data) => {
  // data: { busId, latitude, longitude, timestamp, geofence }
});
```

### Trip Update
```
io.on('trip-update', (data) => {
  // Trip status updated
});
```

### Plate Verified
```
io.on('plate-verified', (data) => {
  // Plate verification completed
});
```

