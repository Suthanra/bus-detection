# Bus Tracking System - Setup Guide

## Prerequisites
- Node.js (v14 or higher)
- MongoDB (local installation or Atlas)
- npm or yarn

## Backend Setup

### 1. Navigate to backend directory
```bash
cd backend
```

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment variables
Create a `.env` file in the backend directory with the following:

```env
# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/bus-tracking-system
MONGODB_USER=
MONGODB_PASSWORD=

# Server Configuration
PORT=5000
NODE_ENV=development
SERVER_URL=http://localhost:5000

# JWT Configuration
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRE=7d

# Google Maps API
GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here

# Socket.io Configuration
SOCKET_CORS_ORIGIN=http://localhost:3000
SOCKET_CORS_CREDENTIALS=true

# GPS Update Interval (in minutes)
GPS_UPDATE_INTERVAL=5

# Geofence Radius (in meters)
GEOFENCE_RADIUS=200

# Data Retention (in days)
GPS_DATA_RETENTION_DAYS=30

# CORS Configuration
CORS_ORIGIN=http://localhost:3000,http://localhost:5173
```

### 4. Ensure MongoDB is running
```bash
# If MongoDB is installed locally
mongod
```

### 5. Start the backend server
```bash
# Development mode with auto-reload
npm run dev

# OR production mode
npm start
```

The server should start on `http://localhost:5000`

## Frontend Setup

### 1. Navigate to frontend directory
```bash
cd frontend
```

### 2. Install dependencies
```bash
npm install
```

### 3. Create `.env` file for frontend
```
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

### 4. Start the development server
```bash
npm run dev
```

The application should open on `http://localhost:3000` or `http://localhost:5173`

## Deployment

### Local Network Access
To access from other devices on your local network:

1. Find your computer's IP address:
   ```bash
   # On Windows
   ipconfig
   
   # On Mac/Linux
   ifconfig
   ```

2. Update CORS settings in backend `.env`:
   ```env
   CORS_ORIGIN=http://YOUR_IP:3000,http://YOUR_IP:5173
   SOCKET_CORS_ORIGIN=http://YOUR_IP:3000
   ```

3. Update frontend URLs to use your IP instead of localhost

### Docker Deployment
Create a `docker-compose.yml` in the root directory:

```yaml
version: '3.8'

services:
  mongodb:
    image: mongo:5
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db

  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - MONGODB_URI=mongodb://mongodb:27017/bus-tracking-system
      - NODE_ENV=production
    depends_on:
      - mongodb

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:5000/api
      - VITE_SOCKET_URL=http://localhost:5000

volumes:
  mongo_data:
```

Run:
```bash
docker-compose up -d
```

## Default Admin Account

To create an admin account, use the registration endpoint:

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "ADMIN001",
    "username": "admin",
    "email": "admin@example.com",
    "password": "admin123",
    "firstName": "Admin",
    "lastName": "User",
    "role": "admin"
  }'
```

## Testing the System

### 1. Register a user
Visit `http://localhost:3000/register` and create an account

### 2. Test GPS Location Submission
```bash
curl -X POST http://localhost:5000/api/gps/update \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "busId": "BUS_ID",
    "latitude": 19.0760,
    "longitude": 72.8777,
    "accuracy": 10,
    "speed": 45
  }'
```

### 3. Create a Bus
```bash
curl -X POST http://localhost:5000/api/buses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "busId": "BUS001",
    "registrationNumber": "MH-01-AB-1234",
    "driverName": "John",
    "conductorName": "Jane",
    "conductorPhone": "9876543210",
    "busType": "AC",
    "capacity": 50,
    "status": "active"
  }'
```

### 4. Create a Station
```bash
curl -X POST http://localhost:5000/api/stations \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "stationId": "STN001",
    "stationName": "Central Station",
    "city": "Mumbai",
    "latitude": 19.0760,
    "longitude": 72.8777,
    "geofenceRadiusMeters": 200,
    "status": "active"
  }'
```

## Troubleshooting

### MongoDB Connection Error
- Ensure MongoDB is running
- Check MONGODB_URI in .env
- Verify firewall settings

### CORS Errors
- Check CORS_ORIGIN in backend .env
- Ensure frontend and backend URLs match in configuration

### Socket.io Connection Failed
- Check SOCKET_CORS_ORIGIN
- Ensure backend is running on the correct port
- Check browser console for errors

### GPS Data Not Showing
- Verify bus exists
- Check geofence radius and station location
- Ensure GPS location is within geofence

## Performance Tips

1. **Database Indexing**: Ensure indexes are created on frequently queried fields
2. **Cron Jobs**: Background jobs run automatically every 5 minutes (geofence check) and daily (cleanup)
3. **Real-time Updates**: Socket.io limits concurrent connections - adjust based on expected users
4. **Data Cleanup**: Old GPS data is automatically deleted after 30 days

## Support

For issues or questions:
1. Check the API documentation
2. Review backend/frontend logs
3. Check MongoDB connection
4. Verify all environment variables are set correctly

