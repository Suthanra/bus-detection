const http = require('http');
const socketIO = require('socket.io');
require('dotenv').config();

const app = require('./app');
const connectDB = require('./config/database');
const socketHandler = require('./socket/socketHandler');
const geofenceCheckJob = require('./jobs/geofenceCheckJob');
const gpsCleanupJob = require('./jobs/gpsCleanupJob');

// Create HTTP server
const server = http.createServer(app);

// Socket.io configuration
const io = socketIO(server, {
  cors: {
    origin: process.env.SOCKET_CORS_ORIGIN || 'http://localhost:3000',
    credentials: process.env.SOCKET_CORS_CREDENTIALS === 'true'
  }
});

// Setup socket handlers
socketHandler(io);

// Make io accessible to routes
app.set('io', io);

const PORT = process.env.PORT || 5000;

// Start server
const startServer = async () => {
  try {
    // Connect to MongoDB
    await connectDB();

    // Start background jobs
    geofenceCheckJob.start();
    gpsCleanupJob.start();

    console.log('Background jobs started');

    // Listen on port
    server.listen(PORT, () => {
      console.log(`\n========================================`);
      console.log(`Bus Tracking System Server`);
      console.log(`========================================`);
      console.log(`Server running on port ${PORT}`);
      console.log(`Environment: ${process.env.NODE_ENV}`);
      console.log(`Socket.io CORS Origin: ${process.env.SOCKET_CORS_ORIGIN}`);
      console.log(`========================================\n`);
    });
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
};

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down gracefully...');
  geofenceCheckJob.stop();
  gpsCleanupJob.stop();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

startServer();

module.exports = server;
