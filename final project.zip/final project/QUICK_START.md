# Quick Start Guide - Bus Tracking System

Get up and running in 5 minutes!

## 🚀 One-Minute Checklist

- ✅ Node.js v14+ installed
- ✅ MongoDB running locally
- ✅ Git clone/download project

## ⚡ Fast Setup (5 minutes)

### Step 1: Backend Setup (2 minutes)
```bash
cd backend
npm install
```

Create `backend/.env` file:
```env
MONGODB_URI=mongodb://localhost:27017/bus-tracking-system
PORT=5000
JWT_SECRET=your_secret_key_here
GOOGLE_MAPS_API_KEY=your_api_key_here
```

Start backend:
```bash
npm run dev
```
✅ Backend running on `http://localhost:5000`

### Step 2: Frontend Setup (2 minutes)
```bash
cd frontend
npm install
```

Create `frontend/.env` file:
```env
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

Start frontend:
```bash
npm run dev
```
✅ Frontend running on `http://localhost:5173`

### Step 3: Create Sample Data (1 minute)
```bash
# Run from project root
bash scripts/create-sample-data.sh
```

## 🎯 First Use

1. Open `http://localhost:5173` in browser
2. **Login with demo credentials:**
   - Username: `admin`
   - Password: `admin123`

3. **Explore:**
   - 📊 Dashboard - System overview
   - 🚌 Bus Management - Manage buses
   - 📍 Stations - View/manage stations
   - 🗺️ Live Map - Real-time tracking

## 📚 Next Steps

- Read [SETUP_GUIDE.md](docs/SETUP_GUIDE.md) for detailed setup
- Check [FEATURES.md](FEATURES.md) for all capabilities
- See [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md) for API details
- Review [TROUBLESHOOTING.md](TROUBLESHOOTING.md) if issues occur

## ⚠️ Common Setup Issues?

**MongoDB not running?**
```bash
mongod
```

**Port 5000 already in use?**
Change `PORT=5001` in backend `.env`

**JavaScript errors in frontend?**
Clear node_modules and reinstall:
```bash
rm -rf node_modules
npm install
```

More help? See [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

## 💡 Key Features Ready to Use

- ✅ Real-time GPS tracking
- ✅ Admin dashboard
- ✅ Live map visualization
- ✅ User authentication
- ✅ Bus & station management

**Happy tracking! 🚀**
