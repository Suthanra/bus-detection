const express = require('express');
const router = express.Router();
const plateController = require('../controllers/plateController');
const authMiddleware = require('../middlewares/authMiddleware');

// All routes require authentication
router.use(authMiddleware);

// Create manual plate entry
router.post('/', plateController.createPlateEntry);

// Get all plate entries
router.get('/', plateController.getAllPlateEntries);

// Search plate by number
router.get('/search/:plateNumber', plateController.searchPlateByNumber);

// Get single plate entry
router.get('/:id', plateController.getPlateEntryById);

// Update plate entry (modify number plate or details)
router.put('/:id', plateController.updatePlateEntry);

// Verify/confirm plate entry
router.post('/:id/verify', plateController.verifyPlateEntry);

// Delete plate entry
router.delete('/:id', plateController.deletePlateEntry);

module.exports = router;
