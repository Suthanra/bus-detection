const express = require('express');
const router = express.Router();
const stationController = require('../controllers/stationController');
const authMiddleware = require('../middlewares/authMiddleware');

// All routes require authentication
router.use(authMiddleware);

// Get all stations
router.get('/', stationController.getAllStations);

// Get single station
router.get('/:id', stationController.getStationById);

// Create station
router.post('/', stationController.createStation);

// Update station
router.put('/:id', stationController.updateStation);

// Delete station
router.delete('/:id', stationController.deleteStation);

module.exports = router;
