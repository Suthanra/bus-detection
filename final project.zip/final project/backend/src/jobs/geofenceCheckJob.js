const cron = require('node-cron');
const Bus = require('../models/Bus');
const GPSLocation = require('../models/GPSLocation');
const geoFenceService = require('../services/geoFenceService');
const tripService = require('../services/tripService');

// Run every 5 minutes
const geofenceCheckJob = cron.schedule('*/5 * * * *', async () => {
  try {
    console.log('[GEOFENCE CHECK JOB] Running at', new Date());

    const buses = await Bus.find({ status: 'active' });

    for (const bus of buses) {
      // Get latest GPS location
      const latestLocation = await GPSLocation.findOne({ busId: bus._id })
        .sort({ timestamp: -1 });

      if (!latestLocation) {
        continue;
      }

      // Check geofence
      const geofenceResult = await geoFenceService.checkBusInGeofence(
        bus._id,
        latestLocation.latitude,
        latestLocation.longitude
      );

      if (geofenceResult.inGeofence) {
        const updatedTrip = await tripService.updateTripStatusByGeofence(
          bus._id,
          geofenceResult.stationId
        );

        if (updatedTrip) {
          console.log(
            `[GEOFENCE] Bus ${bus.busId} detected in geofence of station ${geofenceResult.stationName}`
          );
        }
      }
    }

    console.log('[GEOFENCE CHECK JOB] Completed');
  } catch (error) {
    console.error('[GEOFENCE CHECK JOB] Error:', error);
  }
});

module.exports = geofenceCheckJob;
