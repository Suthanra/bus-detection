# Contributing to Bus Tracking System

Thank you for your interest in contributing! Here's how you can help improve this project.

## 📋 Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

## 🐛 Reporting Bugs

Found a bug? Help us fix it!

1. **Check existing issues** - Avoid duplicates
2. **Provide details:**
   - Operating system
   - Browser (frontend) or Node version (backend)
   - Exact error message
   - Steps to reproduce
   - Expected vs actual behavior
3. **Include relevant code** - Screenshots or code snippets
4. **Attach logs** - Terminal output and console errors

**Example bug report:**
```
Title: Map not loading on Safari
Description:
- OS: macOS 12.5
- Browser: Safari 15.6
- Steps to reproduce:
  1. Open app in Safari
  2. Navigate to Map view
  3. Map area shows gray rectangle
- Error: "Google Maps API key missing"
```

## 🎯 Suggesting Features

Have a great idea? Share it!

1. Check if feature already exists
2. Describe the use case
3. Explain expected behavior
4. Share implementation ideas (optional)

**Example feature request:**
```
Title: Export trip data to CSV
Description: Users should be able to export trip history as CSV for analysis
Use case: Monthly reporting and data analysis
Expected: Add "Export" button in trip list
```

## 💻 Making Changes

### Setup Development Environment

```bash
# Clone/navigate to project
cd "d:\vs code\final project"

# Backend
cd backend
npm install
npm run dev

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

### Code Style Guidelines

**JavaScript/Node.js:**
```javascript
// Use camelCase
const myVariable = "value";

// Use const/let, not var
const config = { timeout: 5000 };

// Arrow functions where appropriate
const calculate = (a, b) => a + b;

// Meaningful names
const getUserById = (id) => { /* ... */ };
const isValidEmail = (email) => { /* ... */ };
```

**React Components:**
```jsx
// Functional components with hooks
const UserProfile = ({ userId }) => {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    // Load user
  }, [userId]);
  
  return <div>Profile Component</div>;
};

export default UserProfile;
```

**Comments:**
```javascript
// Single line comments for code explanation
const timeout = 5000; // milliseconds

// Multi-line for complex logic
/**
 * Validates user email format
 * @param {string} email - Email to validate
 * @returns {boolean} true if valid, false otherwise
 */
const validateEmail = (email) => { /* ... */ };
```

### Code Quality

- **Format code** - Use consistent indentation (2 spaces)
- **Avoid console logs** - Remove debug statements
- **Error handling** - Use try-catch appropriately
- **Comments** - Explain WHY, not WHAT
- **Tests** - Add tests for new features (when applicable)

### File Organization

```
backend/
├── src/
│   ├── models/       # Database schemas
│   ├── controllers/  # Request handlers
│   ├── routes/       # API endpoints
│   ├── services/     # Business logic
│   ├── middlewares/  # Auth, validation
│   └── config/       # Configuration

frontend/
├── src/
│   ├── components/   # Reusable components
│   ├── pages/        # Page components
│   ├── services/     # API calls, socket
│   ├── hooks/        # Custom React hooks
│   └── utils/        # Helper functions
```

### Commit Messages

Write clear, descriptive commit messages:

```
Good:
✅ Add geofence detection for bus arrival
✅ Fix CORS error in frontend API calls
✅ Update MongoDB connection timeout
✅ Refactor trip service for performance

Bad:
❌ fix bug
❌ update code
❌ stuff
```

**Format:**
```
[Type] Brief description (50 chars max)

Longer explanation if needed. Explain WHAT and WHY.

- Bullet points for changes
- Fix issue #123
```

**Types:**
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation
- `style` - Code style (formatting, missing semicolons, etc)
- `refactor` - Code refactoring
- `perf` - Performance improvements
- `test` - Adding tests
- `chore` - Build process, dependencies

**Examples:**
```
feat: Add trip export to CSV functionality

- Implement export button in trip list
- Generate CSV from trip data
- Add download trigger
- Handles large datasets

fix: CORS error preventing API calls

- Add frontend URL to CORS whitelist
- Verify socket.io CORS configuration
- Test cross-origin requests

docs: Update API documentation

- Add pagination examples
- Document error responses
- Include authentication headers
```

## 🔄 Pull Request Process

1. **Create a branch**
   ```bash
   git checkout -b feature/descriptive-name
   # or
   git checkout -b fix/issue-description
   ```

2. **Make your changes**
   - Keep commits atomic and digestible
   - Follow code style guidelines
   - Test your changes

3. **Update relevant files:**
   - Update `.env.example` if adding new variables
   - Update documentation if behavior changes
   - Add comments for complex logic

4. **Verify before submitting:**
   ```bash
   # Backend
   cd backend
   npm run dev
   npm test  # if tests exist
   
   # Frontend
   cd frontend
   npm run dev
   npm run lint
   ```

5. **Create Pull Request**
   - Clear title and description
   - Reference any related issues (#123)
   - Explain what changed and why
   - Include before/after if applicable

**PR Template:**
```
## Description
Brief overview of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement

## Related Issues
Fixes #123

## Testing
- [ ] Tested locally
- [ ] No breaking changes
- [ ] Follows code style

## Changes
- Changed X to fix Y
- Added Z feature
- Updated documentation
```

## 📚 Documentation

When contributing, please update relevant documentation:

- **API changes** - Update [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md)
- **Architecture changes** - Update [ARCHITECTURE.md](docs/ARCHITECTURE.md)
- **Features** - Update [FEATURES.md](FEATURES.md)
- **Setup changes** - Update [SETUP_GUIDE.md](docs/SETUP_GUIDE.md)
- **New issues** - Add to [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

## 🧪 Testing

For new features:

```javascript
// Backend example with Jest
describe('Bus Routes', () => {
  it('should return all buses', async () => {
    const response = await request(app)
      .get('/api/buses')
      .set('Authorization', `Bearer ${token}`);
    
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body)).toBe(true);
  });
});

// Frontend example with testing library
describe('BusList Component', () => {
  it('should display bus list', () => {
    render(<BusList />);
    expect(screen.getByText(/buses/i)).toBeInTheDocument();
  });
});
```

## ⚠️ Important Notes

- Don't modify `.env` files in commits
- Don't include node_modules
- Don't commit API keys or secrets
- Keep changes focused on one issue
- Test thoroughly before PR

## 🎓 Learning Resources

- [Express.js Documentation](https://expressjs.com/)
- [React Documentation](https://react.dev/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [Socket.io Documentation](https://socket.io/docs/)

## 📞 Questions?

- Check existing documentation
- Review similar code in the project
- Comment on issues with questions
- See [GETTING_HELP.md](GETTING_HELP.md)

## 🎉 Recognition

Contributors will be:
- Added to project README
- Mentioned in release notes
- Acknowledged for significant contributions

---

**Thank you for making this project better!** 🚀
