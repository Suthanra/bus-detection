module.exports = {
  GPS_UPDATE_INTERVAL: 5, // minutes
  GEOFENCE_RADIUS: 200, // meters
  GPS_DATA_RETENTION: 30, // days
  
  // Bus statuses
  BUS_STATUS: {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    MAINTENANCE: 'maintenance'
  },

  // Trip statuses
  TRIP_STATUS: {
    SCHEDULED: 'scheduled',
    DEPARTED: 'departed',
    IN_TRANSIT: 'in-transit',
    ARRIVED: 'arrived',
    CANCELLED: 'cancelled'
  },

  // Plate entry statuses
  PLATE_STATUS: {
    PENDING: 'pending',
    VERIFIED: 'verified',
    REJECTED: 'rejected',
    AUTO_MATCHED: 'auto-matched'
  },

  // User roles
  USER_ROLES: {
    ADMIN: 'admin',
    OPERATOR: 'operator',
    VIEWER: 'viewer',
    CONDUCTOR: 'conductor'
  },

  // Error messages
  ERROR_MESSAGES: {
    UNAUTHORIZED: 'Unauthorized access',
    NOT_FOUND: 'Resource not found',
    INVALID_INPUT: 'Invalid input provided',
    DUPLICATE_ENTRY: 'Duplicate entry found'
  }
};
