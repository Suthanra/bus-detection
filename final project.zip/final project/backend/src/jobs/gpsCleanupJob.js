const cron = require('node-cron');
const GPSLocation = require('../models/GPSLocation');

// Run every day at 2 AM
const gpsCleanupJob = cron.schedule('0 2 * * *', async () => {
  try {
    console.log('[GPS CLEANUP JOB] Running at', new Date());

    const retentionDays = parseInt(process.env.GPS_DATA_RETENTION_DAYS) || 30;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    const result = await GPSLocation.deleteMany({
      timestamp: { $lt: cutoffDate }
    });

    console.log(`[GPS CLEANUP JOB] Deleted ${result.deletedCount} old GPS records`);
  } catch (error) {
    console.error('[GPS CLEANUP JOB] Error:', error);
  }
});

module.exports = gpsCleanupJob;
