const mongoose = require('mongoose');

const manualPlateEntrySchema = new mongoose.Schema(
  {
    stationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'BusStation',
      required: true,
      index: true
    },
    capturedNumberPlate: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true
    },
    entryTime: {
      type: Date,
      default: Date.now,
      index: true
    },
    cameraCaptureTime: {
      type: Date,
      default: null
    },
    matchedBusId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bus',
      default: null,
      index: true
    },
    matchedTripId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TripTracking',
      default: null
    },
    status: {
      type: String,
      enum: ['pending', 'verified', 'rejected', 'auto-matched'],
      default: 'pending',
      index: true
    },
    enteredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    verificationNotes: {
      type: String,
      default: null
    },
    gpsMatchDetails: {
      busLatitude: {
        type: Number,
        default: null
      },
      busLongitude: {
        type: Number,
        default: null
      },
      stationLatitude: {
        type: Number,
        default: null
      },
      stationLongitude: {
        type: Number,
        default: null
      },
      distanceFromStation: {
        type: Number,
        default: null // in meters
      },
      withinGeofence: {
        type: Boolean,
        default: false
      }
    },
    isActive: {
      type: Boolean,
      default: true
    }
  },
  {
    timestamps: true
  }
);

// Indexes for efficient queries
manualPlateEntrySchema.index({ entryTime: -1 });
manualPlateEntrySchema.index({ stationId: 1, entryTime: -1 });
manualPlateEntrySchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('ManualPlateEntry', manualPlateEntrySchema);
