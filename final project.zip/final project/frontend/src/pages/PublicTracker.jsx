import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../utils/store';
import { gpsService, tripService, busService } from '../services/apiServices';
import { toast } from 'react-toastify';
import { MapPin, Bus, Clock, AlertCircle } from 'lucide-react';

export default function PublicTracker() {
  const [buses, setBuses] = useState([]);
  const [selectedBusId, setSelectedBusId] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBuses = async () => {
      try {
        const busesData = await busService.getAllBuses();
        setBuses(busesData.data || []);
      } catch (error) {
        toast.error('Failed to load buses');
      } finally {
        setLoading(false);
      }
    };

    fetchBuses();
    const interval = setInterval(fetchBuses, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading buses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-800">Bus Tracking</h1>
          <p className="text-gray-600">Track your bus in real-time</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Map Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center text-gray-600">
              <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Map Integration Coming Soon</p>
              <p className="text-sm text-gray-500">Google Maps API integration required</p>
            </div>
          </div>
        </div>

        {/* Buses List */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Active Buses</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {buses.length > 0 ? (
              buses.map((bus) => (
                <div
                  key={bus._id}
                  className="bg-white rounded-lg shadow p-4 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setSelectedBusId(bus._id)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-800">{bus.busId}</h3>
                      <p className="text-sm text-gray-600">{bus.registrationNumber}</p>
                    </div>
                    <Bus className="w-5 h-5 text-blue-600" />
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Type:</span>
                      <span className="font-medium">{bus.busType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Conductor:</span>
                      <span className="font-medium">{bus.conductorName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className={`font-medium ${bus.status === 'active' ? 'text-green-600' : 'text-red-600'}`}>
                        {bus.status.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {bus.lastLocationUpdate && (
                    <div className="mt-3 pt-3 border-t text-xs text-gray-500">
                      <Clock className="w-3 h-3 inline mr-1" />
                      Last update: {new Date(bus.lastLocationUpdate).toLocaleTimeString()}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="col-span-3 text-center py-8">
                <AlertCircle className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                <p className="text-gray-600">No buses available</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
