const express = require('express');
const router = express.Router();
const tripController = require('../controllers/tripController');
const authMiddleware = require('../middlewares/authMiddleware');

// All routes require authentication
router.use(authMiddleware);

// Create trip
router.post('/', tripController.createTrip);

// Get all trips
router.get('/', tripController.getAllTrips);

// Get single trip
router.get('/:id', tripController.getTripById);

// Update trip
router.put('/:id', tripController.updateTrip);

// Cancel trip
router.put('/:id/cancel', tripController.cancelTrip);

// Get trip history for bus
router.get('/bus/:busId/history', tripController.getTripHistory);

// Get active trip for bus
router.get('/bus/:busId/active', tripController.getActiveTripForBus);

module.exports = router;
