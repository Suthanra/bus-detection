import { create } from 'zustand';

export const useAuthStore = create((set) => ({
  user: null,
  token: localStorage.getItem('authToken'),
  isLoggedIn: !!localStorage.getItem('authToken'),

  setUser: (user) => set({ user }),
  setToken: (token) => set({ token }),
  setLoggedIn: (isLoggedIn) => set({ isLoggedIn }),

  logout: () => {
    set({ user: null, token: null, isLoggedIn: false });
    localStorage.removeItem('authToken');
  }
}));

export const useMapStore = create((set) => ({
  selectedBus: null,
  buses: [],
  stations: [],
  selectedStation: null,

  setSelectedBus: (bus) => set({ selectedBus: bus }),
  setBuses: (buses) => set({ buses }),
  setStations: (stations) => set({ stations }),
  setSelectedStation: (station) => set({ selectedStation: station })
}));

export const useTripStore = create((set) => ({
  trips: [],
  selectedTrip: null,
  filter: 'all',

  setTrips: (trips) => set({ trips }),
  setSelectedTrip: (trip) => set({ selectedTrip: trip }),
  setFilter: (filter) => set({ filter })
}));
