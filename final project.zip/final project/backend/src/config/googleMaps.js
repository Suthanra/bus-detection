const axios = require('axios');

const googleMapsService = {
  // Calculate distance between two points using Haversine formula
  calculateDistance: (lat1, lon1, lat2, lon2) => {
    const R = 6371000; // Earth's radius in meters
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in meters
    
    return distance;
  },

  // Get route and distance using Google Maps API
  getRouteDistance: async (sourceLat, sourceLon, destLat, destLon) => {
    try {
      if (!process.env.GOOGLE_MAPS_API_KEY) {
        console.warn('Google Maps API key not set');
        return null;
      }

      const response = await axios.get(
        'https://maps.googleapis.com/maps/api/distancematrix/json',
        {
          params: {
            origins: `${sourceLat},${sourceLon}`,
            destinations: `${destLat},${destLon}`,
            key: process.env.GOOGLE_MAPS_API_KEY
          }
        }
      );

      if (response.data.status === 'OK' && response.data.rows[0].elements[0].status === 'OK') {
        return {
          distance: response.data.rows[0].elements[0].distance.value, // in meters
          duration: response.data.rows[0].elements[0].duration.value // in seconds
        };
      }

      return null;
    } catch (error) {
      console.error('Google Maps API error:', error.message);
      return null;
    }
  },

  // Get address from coordinates (Reverse Geocoding)
  getAddressFromCoordinates: async (latitude, longitude) => {
    try {
      if (!process.env.GOOGLE_MAPS_API_KEY) {
        return null;
      }

      const response = await axios.get(
        'https://maps.googleapis.com/maps/api/geocode/json',
        {
          params: {
            latlng: `${latitude},${longitude}`,
            key: process.env.GOOGLE_MAPS_API_KEY
          }
        }
      );

      if (response.data.status === 'OK' && response.data.results.length > 0) {
        return response.data.results[0].formatted_address;
      }

      return null;
    } catch (error) {
      console.error('Reverse Geocoding error:', error.message);
      return null;
    }
  }
};

module.exports = googleMapsService;
